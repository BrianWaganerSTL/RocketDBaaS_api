
class NotAllowed(Exception):
    """Exception for attempting to do something that's not allowed."""
