# -*- coding: utf-8 -*-

"""
Helpers to work with luminosities.
"""


__all__ = ["LumiList"]


class LumiList(object):
    """
    TODO.
    """
