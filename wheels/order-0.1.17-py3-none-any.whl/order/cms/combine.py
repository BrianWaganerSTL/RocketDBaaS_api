# -*- coding: utf-8 -*-

"""
Datacard and model definition for statistical inference with the CMS combine tool.
"""


__all__ = ["StatModel", "Datacard"]


class StatModel(object):
    """
    TODO.
    """


class Datacard(object):
    """
    TODO.
    """
